The DBMS folder has the debugging test.
It tests the functions through visual studio

The makeFile and rest of the files are included

This program is meant to run in linux server

Commands to run program:
make
./main
